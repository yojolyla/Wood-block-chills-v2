from pathlib import Path

candidates = [
    Path('src/components/game/woodblock/WoodBlockGame.css'),
    Path('src/components/game/WoodBlockGame.css'),
]
css_path = next((p for p in candidates if p.exists()), None)
if css_path is None:
    raise SystemExit('STOP: WoodBlockGame.css not found')

css = css_path.read_text(encoding='utf-8')
marker = '/* WBC ARCHIVE RESTORED FINAL LAYOUT */'
if marker in css:
    raise SystemExit('OK: archive-restored layout already installed')

css += r'''

/* WBC ARCHIVE RESTORED FINAL LAYOUT
   Reconstructed from the user-approved historical WBC patch chain.
   Does not alter StoryIntro, StoryLibrary, BGM, Settings, or game logic. */
.wbc-viewport {
  background: #2d1b12 !important;
}
.wbc-stage {
  position: relative !important;
  width: 1024px !important;
  height: 1536px !important;
  overflow: hidden !important;
  background-color: #2d1b12 !important;
  background-image: url("../../../assets/ui/wood_block_background.jpeg") !important;
  background-size: 86% auto !important;
  background-position: center 40px !important;
  background-repeat: no-repeat !important;
}
/* Original 1024x2036 paper UI stack, registered as one layer. */
.wbc-ui-layer {
  position: absolute !important;
  left: 0 !important;
  top: -272px !important;
  width: 1024px !important;
  height: 2036px !important;
  transform: none !important;
  pointer-events: none !important;
}
/* Exact recovered 10x10 playable board coordinates in the 1024x1536 stage. */
.wbc-board {
  position: absolute !important;
  left: 143px !important;
  top: 351px !important;
  width: 706px !important;
  height: 675px !important;
}
/* Block Next sits at the desk edge below the board. */
.wbc-tray {
  position: absolute !important;
  left: 90px !important;
  top: 1111px !important;
  width: 844px !important;
  height: 150px !important;
}
'''
css_path.write_text(css, encoding='utf-8')
print('OK: WBC archive-restored final layout installed')
