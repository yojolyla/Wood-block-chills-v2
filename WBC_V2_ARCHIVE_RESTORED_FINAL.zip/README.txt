WBC V2 ARCHIVE RESTORED FINAL

Recovered from the historical files supplied by the user:
- approved warm Asian-room background
- original Story_title_box / Block_board / Block_next PNG layers
- transparent brown/red block source PNGs
- recovered final stage geometry: 1024x1536
- recovered board: x=143, y=351, w=706, h=675
- recovered registered 1024x2036 paper stack offset: -272px
- Block Next tray at desk edge: y=1111

This patch intentionally does NOT replace the current V2 game component or game logic.
It only restores the archived visual assets and final layout override, preserving the
working V2 Story Library, Story Intro and BGM integration.

INSTALL FROM V2 PROJECT ROOT:
unzip -o src/assets/WBC_V2_ARCHIVE_RESTORED_FINAL.zip -d . && python apply_archive_restored_layout.py && rm apply_archive_restored_layout.py src/assets/WBC_V2_ARCHIVE_RESTORED_FINAL.zip

Expected success message:
OK: WBC archive-restored final layout installed
