WBC V2 FINAL SCREEN RESTORE

Adds only the approved room background and recovered top game header to the existing playable V2 block game.
It does NOT replace block game logic and does NOT touch Story Library, Story Intro or BGM.

From V2 project root run:
python apply_v2_final_screen_restore.py

Expected:
OK: V2 FINAL SCREEN RESTORE INSTALLED
