from pathlib import Path

TSX_CANDIDATES = [
    Path('src/components/game/woodblock/WoodBlockGame.tsx'),
    Path('src/components/game/WoodBlockGame.tsx'),
]
CSS_CANDIDATES = [
    Path('src/components/game/woodblock/WoodBlockGame.css'),
    Path('src/components/game/WoodBlockGame.css'),
]

tsx_path = next((p for p in TSX_CANDIDATES if p.exists()), None)
css_path = next((p for p in CSS_CANDIDATES if p.exists()), None)
if tsx_path is None:
    raise SystemExit('STOP: WoodBlockGame.tsx not found')
if css_path is None:
    raise SystemExit('STOP: WoodBlockGame.css not found')

tsx = tsx_path.read_text(encoding='utf-8')
css = css_path.read_text(encoding='utf-8')

IMPORT_MARKER = 'import pipaStoryThumbnail from "../../../assets/ui/pipa_story_thumbnail.jpeg";'
if IMPORT_MARKER not in tsx:
    anchor = 'import woodBlockBrown from "../../../assets/ui/wood_block_brown_original_clean_alpha.png";'
    if anchor not in tsx:
        raise SystemExit('STOP: expected block-image import anchor not found')
    tsx = tsx.replace(anchor, anchor + '\n' + IMPORT_MARKER, 1)

HEADER_MARKER = 'data-wbc-final-header="true"'
if HEADER_MARKER not in tsx:
    anchor = '<img src={uiLayer} alt="" className="wbc-ui-layer" draggable={false} />'
    if anchor not in tsx:
        raise SystemExit('STOP: expected UI-layer anchor not found')
    header = r'''

        <div className="wbc-final-header" data-wbc-final-header="true">
          <div className="wbc-brand">
            <div className="wbc-brand-title">우드 블록</div>
            <div className="wbc-brand-subtitle">한 수의 시작, 자라나는 이야기</div>
          </div>

          <div className="wbc-story-thumb-frame">
            <img className="wbc-story-thumb" src={pipaStoryThumbnail} alt="현재 스토리" draggable={false} />
          </div>

          <div className="wbc-header-score">
            <span>SCORE</span>
            <strong>{score}</strong>
          </div>
          <div className="wbc-header-best">
            {score > 0 && score >= best && <em>NEW!</em>}
            <span>BEST</span>
            <strong>{best}</strong>
          </div>

          <div className="wbc-level-row">
            <div className="wbc-level-labels">
              <span>Lv. {Math.floor(score / 500) + 1}</span>
              <span>{score % 500} / 500</span>
            </div>
            <div className="wbc-level-track">
              <div className="wbc-level-fill" style={{ width: `${((score % 500) / 500) * 100}%` }} />
            </div>
          </div>
        </div>

        <div className="wbc-story-title-text">제1장 · 진흙 속에 핀 작은 꽃송이</div>'''
    tsx = tsx.replace(anchor, anchor + header, 1)

tsx_path.write_text(tsx, encoding='utf-8')

CSS_MARKER = '/* WBC V2 FINAL SCREEN RESTORE — APPROVED BACKGROUND + HEADER */'
if CSS_MARKER not in css:
    css += r'''

/* WBC V2 FINAL SCREEN RESTORE — APPROVED BACKGROUND + HEADER
   Visual-only restore. Board logic, drag/drop, StoryIntro, StoryLibrary and BGM are untouched. */
.wbc-viewport {
  background: #2d1b12 !important;
}
.wbc-stage {
  position: relative !important;
  width: 1024px !important;
  height: 1536px !important;
  overflow: hidden !important;
  background-color: #2d1b12 !important;
  background-image: url("../../../assets/ui/wood_block_background_approved.jpeg") !important;
  background-size: 1024px 1536px !important;
  background-position: 0 0 !important;
  background-repeat: no-repeat !important;
}

/* Re-register the original 1024×2036 paper artwork to the recovered 1024×1536 game stage. */
.wbc-ui-layer {
  position: absolute !important;
  left: 0 !important;
  top: -272px !important;
  width: 1024px !important;
  height: 2036px !important;
  transform: none !important;
  pointer-events: none !important;
  z-index: 1 !important;
}
.wbc-board {
  left: 143px !important;
  top: 351px !important;
  width: 706px !important;
  height: 675px !important;
  z-index: 5 !important;
}
.wbc-tray {
  left: 90px !important;
  top: 1111px !important;
  width: 844px !important;
  height: 150px !important;
  z-index: 6 !important;
}

/* Hide the temporary score labels from the core patch; restored header owns them. */
.wbc-stage > .wbc-score,
.wbc-stage > .wbc-best { display: none !important; }

.wbc-final-header {
  position: absolute;
  left: 0;
  top: 0;
  width: 1024px;
  height: 286px;
  z-index: 8;
  pointer-events: none;
  font-family: Georgia, "Times New Roman", serif;
  color: #f3dfbd;
  text-shadow: 0 2px 4px rgba(0,0,0,.48);
}
.wbc-brand {
  position: absolute;
  left: 150px;
  top: 54px;
  width: 300px;
  text-align: left;
}
.wbc-brand-title {
  font-family: "Noto Serif KR", "Apple SD Gothic Neo", Georgia, serif;
  font-size: 38px;
  font-weight: 700;
  line-height: 1.12;
  letter-spacing: .02em;
  color: #f5e5c8;
}
.wbc-brand-subtitle {
  margin-top: 8px;
  font-family: "Noto Serif KR", "Apple SD Gothic Neo", serif;
  font-size: 17px;
  line-height: 1.3;
  color: #e3cba8;
}
.wbc-story-thumb-frame {
  position: absolute;
  left: 437px;
  top: 30px;
  width: 158px;
  height: 158px;
  padding: 9px;
  box-sizing: border-box;
  background: #ead7b3;
  border: 2px solid rgba(104,65,42,.68);
  box-shadow: 0 7px 18px rgba(0,0,0,.38);
  transform: rotate(-1.4deg);
}
.wbc-story-thumb {
  width: 100%;
  height: 100%;
  display: block;
  object-fit: cover;
  object-position: center 31%;
  filter: saturate(.88) sepia(.08);
}
.wbc-header-score,
.wbc-header-best {
  position: absolute;
  top: 53px;
  width: 116px;
  text-align: center;
  color: #f5e4c6;
}
.wbc-header-score { left: 635px; }
.wbc-header-best { left: 760px; }
.wbc-header-score span,
.wbc-header-best span {
  display: block;
  font-size: 15px;
  font-weight: 700;
  letter-spacing: .14em;
}
.wbc-header-score strong,
.wbc-header-best strong {
  display: block;
  margin-top: 6px;
  font-size: 34px;
  line-height: 1;
  font-weight: 700;
}
.wbc-header-best em {
  position: absolute;
  right: -9px;
  top: -27px;
  padding: 5px 13px 4px;
  border-radius: 18px;
  background: #f1c57d;
  color: #74452e;
  font-size: 13px;
  font-style: normal;
  font-weight: 800;
  letter-spacing: .04em;
  text-shadow: none;
  box-shadow: 0 2px 6px rgba(0,0,0,.25);
}
.wbc-level-row {
  position: absolute;
  left: 385px;
  top: 205px;
  width: 300px;
  color: #f1ddba;
  font-family: "Noto Serif KR", "Apple SD Gothic Neo", Georgia, serif;
}
.wbc-level-labels {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 8px;
  font-size: 18px;
  font-weight: 600;
}
.wbc-level-track {
  height: 11px;
  overflow: hidden;
  border-radius: 999px;
  background: rgba(31,18,12,.62);
  border: 1px solid rgba(236,207,161,.12);
}
.wbc-level-fill {
  height: 100%;
  min-width: 0;
  border-radius: inherit;
  background: linear-gradient(90deg,#e3aa58,#f2cd81);
  box-shadow: 0 0 8px rgba(242,205,129,.45);
}
.wbc-story-title-text {
  position: absolute;
  left: 285px;
  top: 294px;
  width: 440px;
  z-index: 9;
  pointer-events: none;
  text-align: center;
  font-family: "Noto Serif KR", "Apple SD Gothic Neo", Georgia, serif;
  font-size: 21px;
  font-weight: 700;
  line-height: 1.25;
  color: #5d3828;
  text-shadow: 0 1px rgba(255,255,255,.38);
}
.wbc-reset {
  bottom: 18px !important;
  color: #ead4ae !important;
  z-index: 9 !important;
}
'''
    css_path.write_text(css, encoding='utf-8')
else:
    css_path.write_text(css, encoding='utf-8')

print('OK: V2 FINAL SCREEN RESTORE INSTALLED')
