import { useEffect, useState } from "react";

type Props = {
  image: string;
  title: string;
  lines: string[];
  onContinue: () => void;
};

const DESIGN_W = 1024;
const DESIGN_H = 1536;

export default function StoryIntro({ image, title, lines, onContinue }: Props) {
  const [scale, setScale] = useState(1);
  const [imageLoaded, setImageLoaded] = useState(false);
  const [showTitle, setShowTitle] = useState(false);
  const [visibleLines, setVisibleLines] = useState(0);
  const [showContinue, setShowContinue] = useState(false);

  useEffect(() => {
    const updateScale = () => {
      setScale(Math.min(window.innerWidth / DESIGN_W, window.innerHeight / DESIGN_H));
    };
    updateScale();
    window.addEventListener("resize", updateScale);
    return () => window.removeEventListener("resize", updateScale);
  }, []);

  useEffect(() => {
    setImageLoaded(false);
    setShowTitle(false);
    setVisibleLines(0);
    setShowContinue(false);
  }, [image]);

  useEffect(() => {
    if (!imageLoaded) return;
    const timers: number[] = [];
    timers.push(window.setTimeout(() => setShowTitle(true), 550));
    lines.forEach((_, index) => {
      timers.push(window.setTimeout(() => setVisibleLines(index + 1), 1450 + index * 1250));
    });
    timers.push(window.setTimeout(() => setShowContinue(true), 1450 + lines.length * 1250 + 700));
    return () => timers.forEach((timer) => window.clearTimeout(timer));
  }, [imageLoaded, lines]);

  return (
    <div
      className="story-intro-viewport"
      style={{ width: DESIGN_W * scale, height: DESIGN_H * scale }}
    >
      <div
        className="story-intro"
        style={{ transform: `scale(${scale})`, transformOrigin: "top left" }}
      >
        <img
          src={image}
          alt=""
          className={`story-intro-image${imageLoaded ? " story-intro-image-loaded" : ""}`}
          draggable={false}
          onLoad={() => setImageLoaded(true)}
        />

        <div className="story-intro-text">
          <div className={`story-intro-title${showTitle ? " story-intro-title-visible" : ""}`}>
            {title}
          </div>

          {lines.map((line, index) => (
            <div
              key={index}
              className={index < visibleLines ? "story-intro-line story-line-visible" : "story-intro-line"}
            >
              {line || "\u00A0"}
            </div>
          ))}
        </div>

        {showContinue && (
          <button className="story-intro-continue" onClick={onContinue}>
            Continue ›
          </button>
        )}
      </div>
    </div>
  );
}
