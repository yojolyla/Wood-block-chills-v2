import storyLibraryImage from "../assets/Story_library.PNG";

type StoryId = "pipa" | "samurai" | "dream";

type Props = {
  onPick: (story: StoryId) => void;
};

export default function StoryLibrary({ onPick }: Props) {
  return (
    <div className="story-library-image-screen">
      <div className="story-library-image-wrap">
        <img
          src={storyLibraryImage}
          alt="Story Library"
          className="story-library-image"
          draggable={false}
        />

        <button
          className="story-hotspot story-hotspot-pipa"
          aria-label="The Girl with the Pipa"
          onClick={() => onPick("pipa")}
        />

        <button
          className="story-hotspot story-hotspot-samurai"
          aria-label="The Lonely Samurai"
          onClick={() => onPick("samurai")}
        />

        <button
          className="story-hotspot story-hotspot-dream"
          aria-label="The Boy Who Walks in Dreams"
          onClick={() => onPick("dream")}
        />
      </div>
    </div>
  );
}
