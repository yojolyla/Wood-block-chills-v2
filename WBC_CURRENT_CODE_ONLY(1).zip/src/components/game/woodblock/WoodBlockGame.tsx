import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import uiLayer from "../../../assets/ui/Wood_block_ui_final_jihye_forever.png";
import woodBlockRed from "../../../assets/ui/wood_block_red_game_source.png";
import woodBlockBrown from "../../../assets/ui/wood_block_brown_original_clean_alpha.png";
import pipaStoryThumbnail from "../../../assets/ui/pipa_story_thumbnail.jpeg";
import "./WoodBlockGame.css";

const SIZE = 10;
type Shape = number[][];
type Piece = { id: string; shape: Shape };
type Burst = { id: number; r: number; c: number; stars: React.CSSProperties[] };
type ShowerStar = { id: number; left: number; top: number; style: React.CSSProperties };

type Props = {
  onAllClear?: () => void;
};

const SHAPES: Shape[] = [
  [[1]], [[1, 1]], [[1], [1]], [[1, 1, 1]], [[1], [1], [1]],
  [[1, 1, 1, 1]], [[1], [1], [1], [1]], [[1, 1, 1, 1, 1]], [[1], [1], [1], [1], [1]],
  [[1, 1], [1, 1]], [[1, 1, 1], [1, 1, 1], [1, 1, 1]], [[1, 1, 1], [1, 1, 1]], [[1, 1], [1, 1], [1, 1]],
  [[1, 0], [1, 1]], [[0, 1], [1, 1]], [[1, 1], [1, 0]], [[1, 1], [0, 1]],
  [[1, 0, 0], [1, 1, 1]], [[0, 0, 1], [1, 1, 1]], [[1, 1, 1], [1, 0, 0]], [[1, 1, 1], [0, 0, 1]],
  [[1, 1, 1], [0, 1, 0]], [[0, 1, 0], [1, 1, 1]], [[1, 0], [1, 1], [1, 0]], [[0, 1], [1, 1], [0, 1]],
  [[0, 1, 1], [1, 1, 0]], [[1, 1, 0], [0, 1, 1]],
  [[1, 0], [1, 0], [1, 1]], [[0, 1], [0, 1], [1, 1]], [[1, 1], [1, 0], [1, 0]], [[1, 1], [0, 1], [0, 1]],
  [[1, 1], [1, 1], [1, 0]], [[1, 1], [1, 1], [0, 1]], [[1, 0], [1, 1], [1, 1]], [[0, 1], [1, 1], [1, 1]],
  [[1, 1, 1], [1, 1, 0]], [[1, 1, 1], [0, 1, 1]], [[1, 1, 0], [1, 1, 1]], [[0, 1, 1], [1, 1, 1]],
];

const cellCount = (s: Shape) => s.reduce((a, r) => a + r.reduce((b, v) => b + v, 0), 0);
const SMALL_SHAPES = SHAPES.filter((s) => cellCount(s) <= 3);
const LINE_SHAPES = SHAPES.filter((s) => s.length === 1 || s[0].length === 1);
const MEDIUM_SHAPES = SHAPES.filter((s) => cellCount(s) >= 4 && cellCount(s) <= 5 && s.length <= 3 && s[0].length <= 3);
const LARGE_SHAPES = SHAPES.filter((s) => cellCount(s) >= 6);

const emptyBoard = (): number[][] => Array.from({ length: SIZE }, () => Array(SIZE).fill(0));
const makePiece = (shape: Shape): Piece => ({ id: Math.random().toString(36).slice(2), shape });

const canPlace = (board: number[][], shape: Shape, r: number, c: number) => {
  for (let i = 0; i < shape.length; i++) {
    for (let j = 0; j < shape[i].length; j++) {
      if (!shape[i][j]) continue;
      const rr = r + i, cc = c + j;
      if (rr < 0 || cc < 0 || rr >= SIZE || cc >= SIZE || board[rr][cc]) return false;
    }
  }
  return true;
};

const anyPlacement = (board: number[][], shape: Shape) => {
  for (let r = 0; r < SIZE; r++) for (let c = 0; c < SIZE; c++) if (canPlace(board, shape, r, c)) return true;
  return false;
};

const placeOn = (board: number[][], shape: Shape, r: number, c: number) => {
  const next = board.map((row) => row.slice());
  for (let i = 0; i < shape.length; i++) for (let j = 0; j < shape[i].length; j++) if (shape[i][j]) next[r + i][c + j] = 1;
  return next;
};

const allFitSomeOrder = (board: number[][], pieces: Shape[]): boolean => {
  if (pieces.length === 0) return true;
  for (let i = 0; i < pieces.length; i++) {
    const shape = pieces[i];
    for (let r = 0; r < SIZE; r++) {
      for (let c = 0; c < SIZE; c++) {
        if (!canPlace(board, shape, r, c)) continue;
        const nextBoard = placeOn(board, shape, r, c);
        const rest = pieces.slice(0, i).concat(pieces.slice(i + 1));
        if (allFitSomeOrder(nextBoard, rest)) return true;
      }
    }
  }
  return false;
};

const fillRatio = (board: number[][]) => board.flat().filter(Boolean).length / (SIZE * SIZE);
const almostFullLines = (board: number[][]) => {
  const rows: number[] = [], cols: number[] = [];
  for (let r = 0; r < SIZE; r++) {
    const n = board[r].filter(Boolean).length;
    if (n >= 7 && n < SIZE) rows.push(r);
  }
  for (let c = 0; c < SIZE; c++) {
    let n = 0;
    for (let r = 0; r < SIZE; r++) if (board[r][c]) n++;
    if (n >= 7 && n < SIZE) cols.push(c);
  }
  return { rows, cols };
};

const pickShape = (board: number[][], slot: number): Shape => {
  const ratio = fillRatio(board), rand = Math.random();
  if (ratio > 0.4) {
    const pool = rand < 0.65 ? LINE_SHAPES : SMALL_SHAPES;
    return pool[Math.floor(Math.random() * pool.length)];
  }
  if (ratio > 0.2) {
    if (rand < 0.55) return LINE_SHAPES[Math.floor(Math.random() * LINE_SHAPES.length)];
    if (rand < 0.82) return SMALL_SHAPES[Math.floor(Math.random() * SMALL_SHAPES.length)];
    if (rand < 0.95) return MEDIUM_SHAPES[Math.floor(Math.random() * MEDIUM_SHAPES.length)];
    return LARGE_SHAPES[Math.floor(Math.random() * LARGE_SHAPES.length)];
  }
  if (slot === 0 || rand < 0.6) return LINE_SHAPES[Math.floor(Math.random() * LINE_SHAPES.length)];
  if (rand < 0.82) return SMALL_SHAPES[Math.floor(Math.random() * SMALL_SHAPES.length)];
  if (rand < 0.94) return MEDIUM_SHAPES[Math.floor(Math.random() * MEDIUM_SHAPES.length)];
  return LARGE_SHAPES[Math.floor(Math.random() * LARGE_SHAPES.length)];
};

const newTray = (board: number[][] = emptyBoard()): Piece[] => {
  const { rows, cols } = almostFullLines(board);
  const needHoriz = rows.length > 0, needVert = cols.length > 0;
  for (let attempt = 0; attempt < 60; attempt++) {
    const shapes = [pickShape(board, 0), pickShape(board, 1), pickShape(board, 2)];
    if (!allFitSomeOrder(board, shapes)) continue;
    if (needHoriz || needVert) {
      const hasHoriz = shapes.some((s) => s.length === 1);
      const hasVert = shapes.some((s) => s[0].length === 1);
      if ((needHoriz && hasHoriz) || (needVert && hasVert) || attempt > 30) return shapes.map(makePiece);
      continue;
    }
    return shapes.map(makePiece);
  }
  const safe: Shape[] = [];
  for (let i = 0; i < 3; i++) {
    let s = pickShape(board, i), guard = 0;
    while (!anyPlacement(board, s) && guard < 40) { s = SMALL_SHAPES[Math.floor(Math.random() * SMALL_SHAPES.length)]; guard++; }
    safe.push(s);
  }
  return safe.map(makePiece);
};

const TOUCH_LIFT_CELLS = 1.8;
const grainStyle = (r: number, c: number): React.CSSProperties => ({
  backgroundImage: `url(${(r + c) % 2 === 0 ? woodBlockRed : woodBlockBrown})`,
  backgroundSize: "106% 106%",
  backgroundPosition: "center",
  backgroundRepeat: "no-repeat",
  backgroundColor: "transparent",
});

const makeStar = (angleDeg: number, dist: number, scale: number): React.CSSProperties => {
  const rad = (angleDeg * Math.PI) / 180;
  return {
    ["--dx" as never]: `${Math.cos(rad) * dist}px`,
    ["--dy" as never]: `${Math.sin(rad) * dist}px`,
    ["--sc" as never]: scale,
    ["--rt" as never]: `${180 + Math.random() * 360}deg`,
  } as React.CSSProperties;
};

export default function WoodBlockGame({ onAllClear }: Props) {
  const [board, setBoard] = useState<number[][]>(emptyBoard);
  const [tray, setTray] = useState<Piece[]>([]);
  const [selected, setSelected] = useState<string | null>(null);
  const [hover, setHover] = useState<{ r: number; c: number } | null>(null);
  const [dragging, setDragging] = useState(false);
  const [dragPoint, setDragPoint] = useState<{ x: number; y: number } | null>(null);
  const [clearing, setClearing] = useState<Set<string>>(new Set());
  const [bursts, setBursts] = useState<Burst[]>([]);
  const [shower, setShower] = useState<ShowerStar[]>([]);
  const [boardShake, setBoardShake] = useState(false);
  const [clearMode, setClearMode] = useState<"none" | "single" | "combo" | "all">("none");
  const [gameStageScale, setGameStageScale] = useState(1);
  const [score, setScore] = useState(0);
  const [best, setBest] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  const boardRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const update = () => setGameStageScale(Math.min(window.innerWidth / 1024, window.innerHeight / 1536));
    update(); window.addEventListener("resize", update); window.addEventListener("orientationchange", update);
    return () => { window.removeEventListener("resize", update); window.removeEventListener("orientationchange", update); };
  }, []);

  useEffect(() => {
    setTray(newTray());
    setBest(Number(localStorage.getItem("wood-best") || 0));
  }, []);

  useEffect(() => {
    if (score > best) { setBest(score); localStorage.setItem("wood-best", String(score)); }
  }, [score, best]);

  const selectedPiece = useMemo(() => tray.find((p) => p.id === selected) || null, [tray, selected]);

  useEffect(() => {
    if (!tray.length || gameOver || clearing.size > 0) return;
    if (tray.every((p) => !anyPlacement(board, p.shape))) setGameOver(true);
  }, [tray, board, gameOver, clearing]);

  const triggerShower = useCallback((count: number) => {
    const stars: ShowerStar[] = [];
    const w = window.innerWidth, h = window.innerHeight;
    for (let i = 0; i < count; i++) {
      const left = Math.random() * w, top = h * 0.3 + Math.random() * h * 0.3;
      const ang = -90 + (Math.random() - 0.5) * 120, dist = 180 + Math.random() * 260, rad = (ang * Math.PI) / 180;
      stars.push({ id: Math.random(), left, top, style: {
        left: `${left}px`, top: `${top}px`, ["--dx" as never]: `${Math.cos(rad) * dist}px`, ["--dy" as never]: `${Math.sin(rad) * dist + 120}px`, ["--sc" as never]: 0.8 + Math.random() * 1.2,
      } as React.CSSProperties });
    }
    setShower(stars); setTimeout(() => setShower([]), 1500);
  }, []);

  const place = useCallback((r: number, c: number) => {
    if (!selectedPiece || !canPlace(board, selectedPiece.shape, r, c)) return;
    const next = board.map((row) => row.slice());
    let placedCount = 0;
    for (let i = 0; i < selectedPiece.shape.length; i++) for (let j = 0; j < selectedPiece.shape[i].length; j++) if (selectedPiece.shape[i][j]) { next[r + i][c + j] = 1; placedCount++; }

    const fullRows: number[] = [], fullCols: number[] = [];
    for (let i = 0; i < SIZE; i++) { if (next[i].every((v) => v === 1)) fullRows.push(i); if (next.every((row) => row[i] === 1)) fullCols.push(i); }
    const cellsToClear = new Set<string>();
    fullRows.forEach((ri) => Array.from({ length: SIZE }, (_, ci) => cellsToClear.add(`${ri},${ci}`)));
    fullCols.forEach((ci) => Array.from({ length: SIZE }, (_, ri) => cellsToClear.add(`${ri},${ci}`)));

    const postClear = next.map((row) => row.slice());
    cellsToClear.forEach((key) => { const [ri, ci] = key.split(",").map(Number); postClear[ri][ci] = 0; });
    const newTrayList = tray.filter((p) => p.id !== selectedPiece.id);
    setBoard(next); setTray(newTrayList.length === 0 ? newTray(postClear) : newTrayList); setSelected(null); setHover(null);

    const linesCleared = fullRows.length + fullCols.length;
    const lineTable = [0, 100, 250, 500, 900];
    const lineBonus = linesCleared < lineTable.length ? lineTable[linesCleared] : lineTable[lineTable.length - 1] + (linesCleared - 4) * 400;
    setScore((s) => s + placedCount + lineBonus);

    const boardWillBeEmpty = cellsToClear.size > 0 && next.every((row, ri) => row.every((v, ci) => v === 0 || cellsToClear.has(`${ri},${ci}`)));
    if (boardWillBeEmpty) onAllClear?.();

    if (cellsToClear.size > 0) {
      setClearMode(boardWillBeEmpty ? "all" : linesCleared >= 2 ? "combo" : "single");
      setClearing(cellsToClear);
      const burstList: Burst[] = [];
      cellsToClear.forEach((key) => {
        const [ri, ci] = key.split(",").map(Number), starCount = linesCleared >= 3 ? 6 : 4, stars: React.CSSProperties[] = [];
        for (let k = 0; k < starCount; k++) stars.push(makeStar((360 / starCount) * k + Math.random() * 30, 28 + Math.random() * 22, 0.6 + Math.random() * 0.7));
        burstList.push({ id: Math.random(), r: ri, c: ci, stars });
      });
      setBursts(burstList);
      if (linesCleared >= 2) { setBoardShake(true); setTimeout(() => setBoardShake(false), 500); }
      if (linesCleared >= 3) triggerShower(40 + linesCleared * 8);
      setTimeout(() => {
        setBoard((b) => {
          const cleared = b.map((row) => row.slice());
          cellsToClear.forEach((key) => { const [ri, ci] = key.split(",").map(Number); cleared[ri][ci] = 0; });
          return cleared;
        });
        setClearing(new Set());
        setBursts([]);
        setClearMode("none");
      }, boardWillBeEmpty ? 820 : linesCleared >= 2 ? 720 : 640);
    }
  }, [board, selectedPiece, tray, triggerShower, onAllClear]);

  const pointToAnchor = useCallback((clientX: number, clientY: number, shape: Shape) => {
    const el = boardRef.current; if (!el) return null;
    const rect = el.getBoundingClientRect(), cellW = rect.width / SIZE, cellH = rect.height / SIZE;
    const rows = shape.length, cols = shape[0].length;

    // The floating block itself is the pointer. It sits 1.8 board cells above the finger.
    const pieceLeft = clientX - (cols * cellW) / 2;
    const pieceTop = clientY - cellH * TOUCH_LIFT_CELLS - (rows * cellH) / 2;
    const pieceRight = pieceLeft + cols * cellW;
    const pieceBottom = pieceTop + rows * cellH;

    // Forgiving board entry: once 95% of the floating block's bounding box is over the board,
    // snap it to the nearest legal board anchor. Finger position itself is never the anchor.
    const overlapW = Math.max(0, Math.min(pieceRight, rect.right) - Math.max(pieceLeft, rect.left));
    const overlapH = Math.max(0, Math.min(pieceBottom, rect.bottom) - Math.max(pieceTop, rect.top));
    const boardCoverage = (overlapW * overlapH) / Math.max(1, (cols * cellW) * (rows * cellH));
    if (boardCoverage < 0.95) return null;

    const rawC = (pieceLeft - rect.left) / cellW;
    const rawR = (pieceTop - rect.top) / cellH;
    const preferredC = Math.round(rawC);
    const preferredR = Math.round(rawR);

    let best: { r: number; c: number } | null = null;
    let bestDistance = Number.POSITIVE_INFINITY;
    for (let r = 0; r < SIZE; r++) for (let c = 0; c < SIZE; c++) {
      if (!canPlace(board, shape, r, c)) continue;
      const distance = Math.hypot(r - preferredR, c - preferredC);
      if (distance < bestDistance) { bestDistance = distance; best = { r, c }; }
    }

    // Only accept a nearby snap. This prevents a blocked area from jumping to a distant free spot.
    return best && bestDistance <= 0.75 ? best : null;
  }, [board]);

  const lastValidKey = useRef<string | null>(null);
  const lastPreviewAnchor = useRef<{ r: number; c: number } | null>(null);
  const rafId = useRef<number | null>(null);
  const pendingPoint = useRef<{ x: number; y: number } | null>(null);

  useEffect(() => {
    if (!dragging || !selectedPiece) return;
    const flush = () => {
      rafId.current = null; const p = pendingPoint.current; if (!p) return;
      const a = pointToAnchor(p.x, p.y, selectedPiece.shape);
      if (!a) {
        setHover(null);
        lastPreviewAnchor.current = null;
        lastValidKey.current = null;
        return;
      }
      setHover((prev) => (prev && prev.r === a.r && prev.c === a.c ? prev : a));
      const ok = canPlace(board, selectedPiece.shape, a.r, a.c);
      lastPreviewAnchor.current = ok ? a : null;
      const key = ok ? `${a.r},${a.c}` : null;
      if (key && key !== lastValidKey.current && "vibrate" in navigator) { try { navigator.vibrate(8); } catch {} }
      lastValidKey.current = key;
    };
    const move = (e: PointerEvent) => { pendingPoint.current = { x: e.clientX, y: e.clientY }; setDragPoint({ x: e.clientX, y: e.clientY }); if (rafId.current == null) rafId.current = requestAnimationFrame(flush); };
    const up = () => {
      if (rafId.current != null) cancelAnimationFrame(rafId.current); rafId.current = null; pendingPoint.current = null;
      const a = lastPreviewAnchor.current; setDragging(false); setDragPoint(null); lastValidKey.current = null;
      if (a && canPlace(board, selectedPiece.shape, a.r, a.c)) place(a.r, a.c); else setHover(null);
      lastPreviewAnchor.current = null;
    };
    window.addEventListener("pointermove", move, { passive: true }); window.addEventListener("pointerup", up); window.addEventListener("pointercancel", up);
    return () => { window.removeEventListener("pointermove", move); window.removeEventListener("pointerup", up); window.removeEventListener("pointercancel", up); if (rafId.current != null) cancelAnimationFrame(rafId.current); };
  }, [dragging, selectedPiece, board, place, pointToAnchor]);

  const startDrag = (e: React.PointerEvent, piece: Piece) => {
    if (!anyPlacement(board, piece.shape)) return;
    e.preventDefault(); e.stopPropagation(); try { (e.currentTarget as Element).releasePointerCapture?.(e.pointerId); } catch {}
    setSelected(piece.id); setDragging(true); setDragPoint({ x: e.clientX, y: e.clientY });
    const a = pointToAnchor(e.clientX, e.clientY, piece.shape); if (a) { setHover(a); lastPreviewAnchor.current = a; }
  };

  const previewSet = useMemo(() => {
    const s = new Set<string>(); if (!selectedPiece || !hover) return s;
    const { r, c } = hover, ok = canPlace(board, selectedPiece.shape, r, c);
    for (let i = 0; i < selectedPiece.shape.length; i++) for (let j = 0; j < selectedPiece.shape[i].length; j++) if (selectedPiece.shape[i][j]) s.add(`${r + i},${c + j},${ok ? "1" : "0"}`);
    return s;
  }, [selectedPiece, hover, board]);

  const reset = () => { setBoard(emptyBoard()); setTray(newTray()); setSelected(null); setHover(null); setDragging(false); setDragPoint(null); setScore(0); setGameOver(false); setClearing(new Set()); setBursts([]); setShower([]); setClearMode("none"); };

  return (
    <div className="wbc-viewport" style={{ width: 1024 * gameStageScale, height: 1536 * gameStageScale }}>
      <div className="wbc-stage" style={{ transform: `scale(${gameStageScale})` }}>
        <img src={uiLayer} alt="" className="wbc-ui-layer" draggable={false} />

        <div className="wbc-final-header" data-wbc-final-header="true">
          <div className="wbc-brand">
            <div className="wbc-brand-title">WOOD BLOCK</div>
            <div className="wbc-brand-subtitle">One Move Begins, A Story Unfolds</div>
          </div>

          <div className="wbc-story-thumb-frame">
            <img className="wbc-story-thumb" src={pipaStoryThumbnail} alt="현재 스토리" draggable={false} />
          </div>

          <div className="wbc-header-score">
            <span>SCORE</span>
            <strong>{score}</strong>
          </div>
          <div className="wbc-header-best">
            {score > 0 && score >= best && <em>NEW!</em>}
            <span>BEST</span>
            <strong>{best}</strong>
          </div>

          <div className="wbc-level-row">
            <div className="wbc-level-labels">
              <span>Lv. {Math.floor(score / 500) + 1}</span>
              <span>{score % 500} / 500</span>
            </div>
            <div className="wbc-level-track">
              <div className="wbc-level-fill" style={{ width: `${((score % 500) / 500) * 100}%` }} />
            </div>
          </div>
        </div>

        <div className="wbc-story-title-text">CHAPTER I · A LITTLE FLOWER IN THE MUD</div>

        <div className="wbc-score"><span>SCORE</span><strong>{score}</strong></div>
        <div className="wbc-best"><span>BEST</span><strong>{best}</strong></div>

        <div ref={boardRef} className={`wbc-board ${boardShake ? "board-shake" : ""} clear-${clearMode}`}>
          {board.map((row, r) => row.map((cell, c) => {
            const key = `${r},${c}`, filled = cell === 1, isClearing = clearing.has(key), previewOk = previewSet.has(`${r},${c},1`);
            return <div key={key} className={`wbc-cell ${filled ? "filled" : ""} ${isClearing ? "cell-clearing" : ""} ${previewOk ? "snap-valid" : ""}`} style={filled ? { ...grainStyle(r, c), ["--rot" as never]: `${((r * 7 + c * 13) % 11) - 5}deg` } : undefined} />;
          }))}
          {bursts.map((b) => <div key={b.id} className="wbc-burst-cell" style={{ left: `${(b.c / SIZE) * 100}%`, top: `${(b.r / SIZE) * 100}%` }}><div className="star-burst">{b.stars.map((s, i) => <span key={i} className="star" style={s} />)}</div></div>)}
        </div>

        <div className="wbc-tray">
          {tray.map((p) => {
            const isSel = selected === p.id, canUse = anyPlacement(board, p.shape);
            return <button key={p.id} className={`wbc-piece ${isSel ? "selected" : ""} ${!canUse ? "disabled" : ""}`} onPointerDown={(e) => startDrag(e, p)} onClick={() => { if (!dragging && canUse) setSelected(isSel ? null : p.id); }}>
              <div className="wbc-piece-grid" style={{ gridTemplateColumns: `repeat(${p.shape[0].length}, 32px)` }}>
                {p.shape.map((row, i) => row.map((v, j) => <div key={`${i}-${j}`} className="wbc-piece-cell" style={v ? grainStyle(i + p.id.charCodeAt(0), j + (p.id.charCodeAt(1) || 0)) : undefined} />))}
              </div>
            </button>;
          })}
        </div>

        {dragging && selectedPiece && dragPoint && (() => {
          const rect = boardRef.current?.getBoundingClientRect(); if (!rect) return null;
          const cellW = rect.width / SIZE, cellH = rect.height / SIZE, rows = selectedPiece.shape.length, cols = selectedPiece.shape[0].length;

          // Portal to document.body so the stage transform cannot scale/offset the drag ghost a second time.
          // The ghost is therefore exactly the same on-screen size as the board cells.
          return createPortal(
            <div className="wbc-drag-ghost" style={{ left: dragPoint.x, top: dragPoint.y - cellH * TOUCH_LIFT_CELLS, width: cols * cellW, height: rows * cellH, transform: "translate(-50%, -50%)", gridTemplateColumns: `repeat(${cols}, ${cellW}px)`, gridTemplateRows: `repeat(${rows}, ${cellH}px)` }}>
              {selectedPiece.shape.map((row, r) => row.map((v, c) => <div key={`drag-${r}-${c}`} style={{ width: cellW, height: cellH, ...(v ? grainStyle(r + c + selectedPiece.id.charCodeAt(0), c) : {}) }} />))}
            </div>,
            document.body
          );
        })()}

        {gameOver && <div className="wbc-gameover"><div className="wbc-gameover-card"><h2>GAME OVER</h2><p>Score {score}</p><button onClick={reset}>Play Again</button></div></div>}
        <button className="wbc-reset" onClick={reset}>Reset</button>
      </div>
      {shower.length > 0 && <div className="star-shower">{shower.map((s) => <span key={s.id} className="star" style={s.style} />)}</div>}
    </div>
  );
}
