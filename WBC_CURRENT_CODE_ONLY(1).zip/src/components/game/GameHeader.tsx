type Props = {
  score: number;
  onMenu: () => void;
};

export default function GameHeader({ score, onMenu }: Props) {
  return (
    <header className="game-header-v2">
      <div className="score-area">
        <div className="score-label">SCORE</div>
        <div className="score-number">{score}</div>
      </div>

      <button
        className="menu-button-v2"
        onClick={onMenu}
        aria-label="Open menu"
      >
        ☰
      </button>
    </header>
  );
}
