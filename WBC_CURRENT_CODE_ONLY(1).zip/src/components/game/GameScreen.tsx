import WoodBlockGame from "./woodblock/WoodBlockGame";

export default function GameScreen() {
  return (
    <WoodBlockGame
      onAllClear={() => {
        console.log("V2 ALL CLEAR");
      }}
    />
  );
}
