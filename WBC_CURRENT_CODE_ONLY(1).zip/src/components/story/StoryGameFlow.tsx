import { ReactNode, useState } from "react";

type Props = {
  children: (controls: {
    onAllClear: () => void;
    storyOpen: boolean;
  }) => ReactNode;
};

export default function StoryGameFlow({ children }: Props) {
  const [storyOpen, setStoryOpen] = useState(false);

  const onAllClear = () => {
    setStoryOpen(true);
  };

  return (
    <>
      {children({
        onAllClear,
        storyOpen,
      })}

      {storyOpen && (
        <div className="story-game-overlay">
          <div>STORY MOMENT</div>

          <button onClick={() => setStoryOpen(false)}>
            Continue
          </button>
        </div>
      )}
    </>
  );
}
