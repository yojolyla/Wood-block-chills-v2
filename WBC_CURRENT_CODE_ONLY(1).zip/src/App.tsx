import { useRef, useState } from "react";
import loginClip from "./assets/Loggin_clip.MOV";
import pipaStory01 from "./assets/pipastory_01.png";
import pipaBgm from "./assets/Pipa_bgm.m4a";
import StoryLibrary from "./components/StoryLibrary";
import StoryIntro from "./components/StoryIntro";
import GameScreen from "./components/game/GameScreen";
import "./App.css";

type StoryId = "pipa" | "samurai" | "dream";
type Screen = "opening" | "library" | "story" | "game";

export default function App() {
  const bgmRef = useRef<HTMLAudioElement | null>(null);

  const startPipaBgm = () => {
    if (!bgmRef.current) {
      bgmRef.current = new Audio(pipaBgm);
      bgmRef.current.loop = true;
      bgmRef.current.volume = 0.45;
    }

    bgmRef.current.play().catch((error) => {
      console.warn("BGM play failed:", error);
    });
  };

  const [screen, setScreen] = useState<Screen>("opening");
  const [selectedStory, setSelectedStory] = useState<StoryId | null>(null);

  if (screen === "opening") {
    return (
      <div className="login-screen">
        <video
          className="login-video"
          src={loginClip}
          autoPlay
          muted
          playsInline
          onEnded={() => setScreen("library")}
        />
      </div>
    );
  }

  if (screen === "library") {
    return (
      <StoryLibrary
        onPick={(story) => {
          if (story === "pipa") {
            startPipaBgm();
          }
          setSelectedStory(story);
          setScreen("story");
        }}
      />
    );
  }

  if (screen === "game") {
    return <GameScreen />;
  }

  if (selectedStory === "pipa") {
    return (
      <StoryIntro
        image={pipaStory01}
        title="CHAPTER I · CHILD OF THE MARKET"
        lines={[
          "The war was over,",
          "but the child had no home to return to.",
          "",
          "The people shared what little they had,",
          "and she grew up a child of the market.",
          "",
          "One day,",
          "a blind old man was being pushed around.",
          "",
          "Even as he fell,",
          "he would not let go of his old pipa.",
          "",
          "As though it were dearer than life itself.",
        ]}
        onContinue={() => {
          setScreen("game");
        }}
      />
    );
  }

  return (
    <main className="story-placeholder">
      <h1>{selectedStory}</h1>
      <p>Story intro will go here.</p>
    </main>
  );
}
