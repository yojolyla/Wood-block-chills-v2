WBC V1 ORIGINAL CLEAR 1:1 RESTORE

BASE:
- Latest source snapshot: WBC_DRAG_FIX_SOURCE.zip

REFERENCE:
- Original source: wood-block-chills-main.zip

RESTORED FROM THE ORIGINAL V1 VALUES:
- wood-splinter clear animation: exact timings/transforms/easing
- star burst shape, size, gradient, glow, duration, easing
- big-combo star shower shape, size, glow, duration, easing
- board shake coordinates, duration, easing
- per-cell --rot value used by the V1 splinter animation
- shower animationDelay (0–0.15s) that was missing in V2
- V1 clear/place audio implementation
- original clear.mp3 and place.mp3
- V1 clear sound timing/intensity and vibration patterns

IMPORTANT:
This is not a redesigned/recreated clear effect.
The effect constants and CSS animation values are copied from the original
wood-block-chills-main.zip source and adapted only to the current V2 component
path/class structure so the same V1 behavior can render inside V2.
