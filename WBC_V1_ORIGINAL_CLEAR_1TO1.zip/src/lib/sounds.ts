// Sample-based sound effects using user-provided mahjong recordings.
// - playWoodThunk: 마작패 놓는 소리 (single tile placement)
// - playWoodCrash: 마작패 섞는 소리 (tiles shuffling — line clear)

import placeUrl from "@/assets/sfx/place.mp3";
import clearUrl from "@/assets/sfx/clear.mp3";

let ctx: AudioContext | null = null;
let masterGain: GainNode | null = null;
let sfxVolume = 1.6;

const buffers: Record<string, AudioBuffer | null> = {};
const loading: Record<string, Promise<AudioBuffer | null> | undefined> = {};

const getCtx = (): AudioContext | null => {
  if (typeof window === "undefined") return null;
  try {
    if (!ctx) {
      const AC =
        (window as unknown as { AudioContext?: typeof AudioContext }).AudioContext ||
        (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!AC) return null;
      ctx = new AC();
      masterGain = ctx.createGain();
      masterGain.gain.value = sfxVolume;
      // Gentle safety limiter only — keep it transparent so the volume
      // slider produces clearly audible changes across its whole range.
      const comp = ctx.createDynamicsCompressor();
      comp.threshold.value = -2;
      comp.knee.value = 2;
      comp.ratio.value = 2;
      comp.attack.value = 0.005;
      comp.release.value = 0.25;
      masterGain.connect(comp).connect(ctx.destination);
    }
    if (ctx.state === "suspended") void ctx.resume();
    return ctx;
  } catch {
    return null;
  }
};

export function setSfxVolume(v: number) {
  sfxVolume = Math.max(0, Math.min(3, v));
  if (masterGain) masterGain.gain.value = sfxVolume;
}

async function loadBuffer(c: AudioContext, url: string): Promise<AudioBuffer | null> {
  if (buffers[url]) return buffers[url];
  if (loading[url]) return loading[url]!;
  loading[url] = (async () => {
    try {
      const res = await fetch(url);
      const arr = await res.arrayBuffer();
      const buf = await c.decodeAudioData(arr);
      buffers[url] = buf;
      return buf;
    } catch {
      return null;
    }
  })();
  return loading[url]!;
}

function playSample(url: string, opts: { gain?: number; rate?: number; pan?: number } = {}) {
  const c = getCtx();
  if (!c || !masterGain) return;
  const buf = buffers[url];
  if (!buf) {
    void loadBuffer(c, url);
    return;
  }
  const src = c.createBufferSource();
  src.buffer = buf;
  src.playbackRate.value = opts.rate ?? 1;
  const g = c.createGain();
  g.gain.value = opts.gain ?? 1;
  let node: AudioNode = g;
  try {
    if (opts.pan !== undefined) {
      const p = c.createStereoPanner();
      p.pan.value = Math.max(-1, Math.min(1, opts.pan));
      g.connect(p);
      node = p;
    }
  } catch {
    /* noop */
  }
  src.connect(g);
  node.connect(masterGain);
  src.start();
}

// Preload on first user interaction
export function preloadSfx() {
  const c = getCtx();
  if (!c) return;
  void loadBuffer(c, placeUrl);
  void loadBuffer(c, clearUrl);
}

if (typeof window !== "undefined") {
  const kick = () => {
    preloadSfx();
    window.removeEventListener("pointerdown", kick);
    window.removeEventListener("keydown", kick);
  };
  window.addEventListener("pointerdown", kick, { once: true });
  window.addEventListener("keydown", kick, { once: true });
}

/** Place sound — 마작패 놓는 소리 */
export function playWoodThunk() {
  const rate = 0.96 + Math.random() * 0.08;
  const pan = (Math.random() - 0.5) * 0.3;
  playSample(placeUrl, { gain: 1.0, rate, pan });
}

/** Line clear — 마작패 섞는 소리 (5초, 묵직하게 보정) */
export function playWoodCrash(intensity = 1) {
  const i = Math.max(0.5, Math.min(2, intensity));
  playSample(clearUrl, { gain: 1.0 * (0.9 + 0.15 * i), rate: 1.0 });
}

// ===== Compatibility no-op ambient (BGM is handled by YouTube iframe) =====
export function isAmbientPlaying() { return false; }
export function stopAmbient() { /* noop */ }
export function startAmbient() { /* noop */ }
export function toggleAmbient() { return false; }
