WBC WOOD CLEAR CLEAN REPLACEMENT

이 ZIP은 프로젝트 전체를 교체하는 파일이 아닙니다.
아래 2개 활성 파일만 교체하면 됩니다.

1) src/components/game/woodblock/WoodBlockGame.tsx
2) src/components/game/woodblock/WoodBlockGame.css

정리/변경 내용
- 기존 clear-pop / crumble / wood-splinter / popcorn / independent jitter 중복 효과 제거
- 기존 전체 보드 흔들림 제거
- 기존 별 폭발 / star shower를 클리어 시 비활성화
- 클리어 블럭 자체에만 하나의 WBC 나무 물리 효과 연결
- 약 1초 독립적인 나무 충돌 -> TAK 충격 -> 위치 기반 바깥쪽 비산 + 회전 + 중력 낙하
- 블럭은 끝까지 원래 크기/불투명도/나무 질감을 유지
- 아주 작은 나무 조각 2개만 충격 순간 추가
- single / combo / all clear는 같은 재질 언어를 유지하면서 힘/시간만 조금 증가

보존 대상
- NEXT/tray 로직
- drag UX
- drag ghost 크기
- placement / snap
- 점수 계산
- 게임오버 판정
- 배경/헤더/UI 배치
- 스토리 콜백(onAllClear)

중요
- 기존 src 전체를 삭제하지 마세요.
- 위 2개 파일만 같은 경로에 덮어쓰기 하세요.
- 정상 동작 확인 전에는 기존 .BACKUP/.before_* 파일을 삭제하지 마세요.
