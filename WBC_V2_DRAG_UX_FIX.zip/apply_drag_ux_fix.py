from pathlib import Path
import shutil, sys

target = Path('src/components/game/woodblock/WoodBlockGame.tsx')
source = Path(__file__).parent / 'patch_files' / 'WoodBlockGame.tsx'
if not target.exists():
    print('STOP: src/components/game/woodblock/WoodBlockGame.tsx not found')
    sys.exit(1)
if not source.exists():
    print('STOP: patch source missing')
    sys.exit(1)
current = target.read_text(encoding='utf-8')
required = ['TOUCH_LIFT_CELLS = 1.8', 'wbc-drag-ghost', 'pointToAnchor']
if not all(x in current for x in required):
    print('STOP: current WoodBlockGame.tsx is not the expected V2 drag source')
    sys.exit(1)
backup = target.with_suffix('.tsx.before_drag_ux_fix')
shutil.copy2(target, backup)
shutil.copy2(source, target)
written = target.read_text(encoding='utf-8')
checks = ['createPortal', 'boardCoverage < 0.95', 'lastPreviewAnchor.current = null', 'TOUCH_LIFT_CELLS = 1.8']
if not all(x in written for x in checks):
    shutil.copy2(backup, target)
    print('STOP: verification failed; original restored')
    sys.exit(1)
print('OK: DRAG UX FIX INSTALLED')
