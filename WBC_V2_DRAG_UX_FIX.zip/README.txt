WBC V2 Drag UX Fix
- Dragged piece becomes exact on-screen board-cell size.
- Keeps TOUCH_LIFT_CELLS = 1.8.
- Floating block, not fingertip, determines placement.
- Requires 95% of floating block bounding box over board before snap.
- Snaps only to a nearby legal anchor (no distant jumping).
- Moving back to Next/outside board clears preview; release cancels and returns piece to tray.
- Does not modify board visuals, Story Library, Story Intro, BGM, scoring, clearing, or tray generation.
